
% Clear variables and close figures
clear
close all

% Load data
load basisData.mat % Loads X and y
n = size(X,1);

% Adding the bias column in X and Xtest
X = [ones(size(X)) X];
Xtest = [ones(size(Xtest)) Xtest];

% Adding the polynomial basis in X and Xtest
degree = input('Enter the degree greater than 1: ');
X_data = X(:,2);
Xtest_data = Xtest(:,2);
for i = 2:degree
    new_col_X = X_data.^i;
    new_col_Xtest = Xtest_data.^i;
    X = [X new_col_X];
    Xtest = [Xtest new_col_Xtest];
end

% Fit least-squares model
model = leastSquares(X,y);

% Compute training error
yhat = model.predict(model,X);
trainError = sum((yhat - y).^2)/n;
fprintf('Training error = %.2f\n',trainError);

% Compute test error
t = size(Xtest,1);
yhat = model.predict(model,Xtest);
testError = sum((yhat - ytest).^2)/t;
fprintf('Test error = %.2f\n',testError);

% Plot model
figure(1);
X = X(:, 2);
plot(X,y,'b.');
title('Training Data');
hold on
Xhat = (min(X):.1:max(X))'; % Choose points to evaluate the function
Xhat_withbias = [ones(size(Xhat)) Xhat];
for i = 2:degree
    new_col_X = Xhat.^i;
    Xhat_withbias = [Xhat_withbias new_col_X];
end
yhat = model.predict(model,Xhat_withbias);
plot(Xhat,yhat,'g', LineWidth=1);
